package ejer18Huevo;

public class Huevo {
	public Clara clara;
	public Yema yema;

	Huevo() {
		clara = new Clara();
		yema = new Yema();
	}

	public String toString() {
		return "Huevo [clara=" + clara + ", yema=" + yema + "]";
	}

	public class Clara {
		public String toString() {
			return String.format("%s", getClass().getSimpleName().toLowerCase());
		}
	}

	public class Yema {
		public String toString() {
			return String.format("%s", getClass().getSimpleName().toLowerCase());
		}
	}

}
