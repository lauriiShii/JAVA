package ejer18Huevo;

public class Main {

	public static void main(String[] args) {
		Huevo a = new Huevo();
		System.out.println(a);

	}

}
