package ejer9;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Created by José Luis on 11/04/2016.
 *  9. Realiza un método que reciba una fecha y devuelva si dicha fecha es correcta.
 */
public class Main {
    public static boolean metodo(String fecha){
        try {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            formato.setLenient(false); // Quita que se pueda sumar si es erroneo
            formato.parse(fecha);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }
    public static void main(String[] args) {
        System.out.println(metodo("29/2/2015"));
    }


}
