package ejer5;

import java.util.Calendar;

/**
 * Created by José Luis Moreno on 15/04/2016.
 */
public class ejer5 {
    public static int contarDias(int dia, int mes){
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, mes, dia);
        return c.get(Calendar.DAY_OF_YEAR);
    }
    public static void main(String[] args) {
        System.out.println(contarDias(15, 3));
    }
}
